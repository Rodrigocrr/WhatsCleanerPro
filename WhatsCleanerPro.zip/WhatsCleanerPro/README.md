# WhatsCleaner Pro

1. Descompacte e abra a pasta WhatsCleanerPro no Android Studio (File > Open).
2. Aguarde o Gradle sincronizar (JDK 17 — o embutido do Android Studio serve).
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. O APK fica em app/build/outputs/apk/debug/app-debug.apk
