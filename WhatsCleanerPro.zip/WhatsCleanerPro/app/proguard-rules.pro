# sem regras extras
