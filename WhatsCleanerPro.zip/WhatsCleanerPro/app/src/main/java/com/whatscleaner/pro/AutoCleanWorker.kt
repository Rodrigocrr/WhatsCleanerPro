package com.whatscleaner.pro

import android.content.Context
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

class AutoCleanWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            return@withContext Result.success()
        }
        try {
            val (count, bytes) = FileScanner.autoClean()
            Log.i(TAG, "Limpeza automática: " + count + " arquivos, " + formatSize(bytes))
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "AutoCleanWorker"
        private const val WORK_NAME = "auto_clean_weekly"

        /** Atraso até o próximo domingo às 3h */
        private fun delayToNextSunday3am(): Long {
            val now = Calendar.getInstance()
            val next = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY)
                set(Calendar.HOUR_OF_DAY, 3)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                while (!after(now)) add(Calendar.WEEK_OF_YEAR, 1)
            }
            return next.timeInMillis - now.timeInMillis
        }

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<AutoCleanWorker>(7, TimeUnit.DAYS)
                .setInitialDelay(delayToNextSunday3am(), TimeUnit.MILLISECONDS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
