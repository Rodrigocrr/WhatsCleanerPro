package com.whatscleaner.pro

import android.os.Environment
import java.io.File
import java.util.Locale

data class FileItem(
    val file: File,
    val size: Long,
    val modified: Long,
    var selected: Boolean = false
)

enum class Category(val title: String) {
    PHOTOS("Fotos"),
    VIDEOS("Vídeos"),
    AUDIOS("Áudios"),
    DOCS("Documentos"),
    STICKERS("Figurinhas"),
    TELEGRAM("Telegram"),
    JUNK("Lixo"),
    DOWNLOADS("Downloads")
}

fun formatSize(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024.0)
    else String.format(Locale.US, "%.1f MB", mb)
}

object FileScanner {

    private const val DAY = 86_400_000L
    private const val HEAVY_DOWNLOAD = 1L * 1024 * 1024 // >= 1 MB

    private val root: File get() = Environment.getExternalStorageDirectory()

    // Pasta nova (Android 11+) e pasta antiga
    private fun waBases() = listOf(
        File(root, "Android/media/com.whatsapp/WhatsApp"),
        File(root, "WhatsApp")
    )

    private fun tgBases() = listOf(
        File(root, "Android/media/org.telegram.messenger/Telegram"),
        File(root, "Telegram")
    )

    private fun wa(vararg sub: String) =
        waBases().flatMap { base -> sub.map { File(base, "Media/" + it) } }

    private fun tg(vararg sub: String) =
        tgBases().flatMap { base -> sub.map { File(base, it) } }

    private fun thumbnailDirs() = listOf(
        File(root, "DCIM/.thumbnails"),
        File(root, ".thumbnails"),
        File(root, "Pictures/.thumbnails")
    )

    private fun whatsAppCacheDirs() = waBases().flatMap {
        listOf(File(it, ".Shared"), File(it, ".Thumbs"), File(it, ".trash"))
    } + listOf(
        // Só acessível no Android 10 ou inferior; no 11+ o sistema bloqueia /Android/data
        File(root, "Android/data/com.whatsapp/cache")
    )

    fun dirsFor(cat: Category): List<File> = when (cat) {
        Category.PHOTOS -> wa("WhatsApp Images")
        Category.VIDEOS -> wa("WhatsApp Video")
        Category.AUDIOS -> wa("WhatsApp Audio", "WhatsApp Voice Notes")
        Category.DOCS -> wa("WhatsApp Documents")
        Category.STICKERS -> wa("WhatsApp Stickers")
        Category.TELEGRAM -> tg("Telegram Images", "Telegram Video", "Telegram Documents", "Telegram Audio")
        Category.JUNK -> thumbnailDirs() + whatsAppCacheDirs()
        Category.DOWNLOADS -> listOf(File(root, Environment.DIRECTORY_DOWNLOADS))
    }

    private fun walk(dirs: List<File>): List<FileItem> {
        val seen = HashSet<String>()
        val out = ArrayList<FileItem>()
        for (dir in dirs) {
            if (!dir.exists() || !dir.isDirectory) continue
            dir.walkTopDown()
                .onFail { _, _ -> }
                .filter { it.isFile && it.name != ".nomedia" }
                .forEach { f ->
                    val path = try { f.canonicalPath } catch (e: Exception) { f.absolutePath }
                    if (seen.add(path)) out.add(FileItem(f, f.length(), f.lastModified()))
                }
        }
        return out
    }

    fun scan(cat: Category): List<FileItem> {
        val list = walk(dirsFor(cat))
        return if (cat == Category.DOWNLOADS) {
            list.filter { it.size >= HEAVY_DOWNLOAD }.sortedByDescending { it.size }
        } else {
            list.sortedByDescending { it.modified }
        }
    }

    fun totalSize(cat: Category): Long = scan(cat).sumOf { it.size }

    /** Apaga os arquivos. Retorna (quantidade apagada, bytes liberados). */
    fun delete(items: List<FileItem>): Pair<Int, Long> {
        var count = 0
        var bytes = 0L
        for (item in items) {
            try {
                if (item.file.delete()) {
                    count++
                    bytes += item.size
                }
            } catch (_: Exception) { }
        }
        return count to bytes
    }

    /** Limpeza automática: vídeos e áudios (WhatsApp + Telegram) com +30 dias e todas as .thumbnails */
    fun autoClean(): Pair<Int, Long> {
        val limit = System.currentTimeMillis() - 30 * DAY
        val oldMedia = walk(
            wa("WhatsApp Video", "WhatsApp Audio", "WhatsApp Voice Notes") +
                tg("Telegram Video", "Telegram Audio")
        ).filter { it.modified < limit }
        val thumbs = walk(thumbnailDirs())
        return delete(oldMedia + thumbs)
    }
}
