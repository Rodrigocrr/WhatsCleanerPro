package com.whatscleaner.pro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.tabs.TabLayout
import com.whatscleaner.pro.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: FileAdapter
    private var currentCategory = Category.PHOTOS
    private var loadJob: Job? = null
    private var sizesLoaded = false

    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    private val mediaPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            openAllFilesSettingsOrRefresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = FileAdapter { updateFooter() }
        binding.recycler.layoutManager = GridLayoutManager(this, 3)
        binding.recycler.adapter = adapter

        Category.values().forEach { cat ->
            binding.tabLayout.addTab(binding.tabLayout.newTab().setText(cat.title).setTag(cat))
        }
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentCategory = tab.tag as Category
                loadCategory()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) { loadCategory() }
        })

        binding.btnPermission.setOnClickListener { requestPermissions() }

        binding.btnSelectAll.setOnClickListener { adapter.selectAll(!adapter.allSelected()) }
        binding.btnSelect15.setOnClickListener { adapter.selectOlderThan(15) }
        binding.btnDelete.setOnClickListener { confirmDelete() }

        binding.switchAuto.isChecked = prefs.getBoolean("auto_clean", false)
        binding.switchAuto.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("auto_clean", checked).apply()
            if (checked) {
                AutoCleanWorker.schedule(this)
                Toast.makeText(this, "Limpeza automática ativada (domingo 3h)", Toast.LENGTH_SHORT).show()
            } else {
                AutoCleanWorker.cancel(this)
                Toast.makeText(this, "Limpeza automática desativada", Toast.LENGTH_SHORT).show()
            }
        }
        updateFooter()
    }

    override fun onResume() {
        super.onResume()
        if (hasStoragePermission()) {
            binding.permissionLayout.visibility = View.GONE
            binding.contentLayout.visibility = View.VISIBLE
            if (!sizesLoaded) {
                sizesLoaded = true
                loadCategory()
                refreshSizes()
            }
        } else {
            binding.permissionLayout.visibility = View.VISIBLE
            binding.contentLayout.visibility = View.GONE
        }
    }

    // ---------------- PERMISSÕES ----------------

    private fun hasStoragePermission(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    private fun requestPermissions() {
        val perms = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            else -> arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }
        mediaPermLauncher.launch(perms)
    }

    private fun openAllFilesSettingsOrRefresh() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        .setData(Uri.parse("package:" + packageName))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else if (!hasStoragePermission()) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:" + packageName))
            )
        } else {
            onResume()
        }
    }

    // ---------------- LISTAGEM ----------------

    private fun loadCategory() {
        val cat = currentCategory
        loadJob?.cancel()
        binding.progress.visibility = View.VISIBLE
        binding.tvEmpty.visibility = View.GONE
        adapter.submit(emptyList())
        loadJob = lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { FileScanner.scan(cat) }
            if (cat != currentCategory) return@launch
            binding.progress.visibility = View.GONE
            adapter.submit(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            setTabSize(cat, list.sumOf { it.size })
        }
    }

    private fun refreshSizes() {
        lifecycleScope.launch {
            var total = 0L
            for (cat in Category.values()) {
                val size = withContext(Dispatchers.IO) { FileScanner.totalSize(cat) }
                total += size
                setTabSize(cat, size)
            }
            binding.tvTotal.text = "Total encontrado: " + formatSize(total)
        }
    }

    private fun setTabSize(cat: Category, size: Long) {
        binding.tabLayout.getTabAt(cat.ordinal)?.text = cat.title + " (" + formatSize(size) + ")"
    }

    private fun updateFooter() {
        val sel = adapter.selected()
        binding.tvFooter.text = sel.size.toString() + " selecionados | " + formatSize(sel.sumOf { it.size })
        binding.btnDelete.isEnabled = sel.isNotEmpty()
        binding.btnSelectAll.text = if (adapter.allSelected()) "Desmarcar tudo" else "Selecionar tudo"
    }

    // ---------------- APAGAR ----------------

    private fun confirmDelete() {
        val sel = adapter.selected()
        if (sel.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Apagar arquivos?")
            .setMessage(
                "Você vai apagar " + sel.size + " arquivo(s) (" + formatSize(sel.sumOf { it.size }) +
                    ").\n\nEssa ação NÃO pode ser desfeita."
            )
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("APAGAR") { _, _ -> doDelete(sel) }
            .show()
    }

    private fun doDelete(sel: List<FileItem>) {
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val (count, bytes) = withContext(Dispatchers.IO) { FileScanner.delete(sel) }
            Toast.makeText(
                this@MainActivity,
                count.toString() + " arquivos apagados • " + formatSize(bytes) + " liberados",
                Toast.LENGTH_LONG
            ).show()
            loadCategory()
            refreshSizes()
        }
    }
}
