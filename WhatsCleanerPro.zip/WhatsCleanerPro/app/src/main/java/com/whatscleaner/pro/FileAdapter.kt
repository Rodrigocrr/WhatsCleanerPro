package com.whatscleaner.pro

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.whatscleaner.pro.databinding.ItemFileBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FileAdapter(
    private val onSelectionChanged: () -> Unit
) : RecyclerView.Adapter<FileAdapter.VH>() {

    private val items = mutableListOf<FileItem>()
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

    private val imageExt = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic")
    private val videoExt = setOf("mp4", "3gp", "mkv", "mov", "avi", "webm")
    private val audioExt = setOf("opus", "mp3", "m4a", "aac", "ogg", "wav", "amr")

    inner class VH(val b: ItemFileBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(list: List<FileItem>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun selected(): List<FileItem> = items.filter { it.selected }

    fun allSelected(): Boolean = items.isNotEmpty() && items.all { it.selected }

    fun selectAll(select: Boolean) {
        items.forEach { it.selected = select }
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun selectOlderThan(days: Int) {
        val limit = System.currentTimeMillis() - days * 86_400_000L
        items.forEach { it.selected = it.modified < limit }
        notifyDataSetChanged()
        onSelectionChanged()
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemFileBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val b = holder.b
        b.tvName.text = item.file.name
        b.tvSize.text = formatSize(item.size)
        b.tvDate.text = dateFmt.format(Date(item.modified))
        b.checkBox.isChecked = item.selected
        b.selectedOverlay.visibility = if (item.selected) View.VISIBLE else View.GONE

        val ext = item.file.extension.lowercase(Locale.ROOT)
        val isVideo = ext in videoExt
        b.ivPlay.visibility = if (isVideo) View.VISIBLE else View.GONE

        // .thumbnails geralmente não têm extensão mas são imagens
        val isThumbFile = item.file.parentFile?.name == ".thumbnails"
        if (ext in imageExt || isVideo || isThumbFile) {
            b.ivThumb.scaleType = ImageView.ScaleType.CENTER_CROP
            Glide.with(b.ivThumb)
                .load(item.file)
                .centerCrop()
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(b.ivThumb)
        } else {
            Glide.with(b.ivThumb).clear(b.ivThumb)
            b.ivThumb.scaleType = ImageView.ScaleType.CENTER_INSIDE
            b.ivThumb.setImageResource(
                if (ext in audioExt) android.R.drawable.ic_media_play
                else android.R.drawable.ic_menu_agenda
            )
        }

        b.root.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p == RecyclerView.NO_POSITION) return@setOnClickListener
            items[p].selected = !items[p].selected
            notifyItemChanged(p)
            onSelectionChanged()
        }
    }
}
